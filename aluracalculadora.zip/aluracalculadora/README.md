# ALURA - Calculadora

A Pen created on CodePen.io. Original URL: [https://codepen.io/giovannanovelli/pen/poVJgmg](https://codepen.io/giovannanovelli/pen/poVJgmg).

